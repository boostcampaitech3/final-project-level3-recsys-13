.. automodule:: recbole.model.knowledge_aware_recommender.mkr
   :members:
   :undoc-members:
   :show-inheritance:
