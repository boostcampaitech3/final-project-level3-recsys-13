.. automodule:: recbole.model.sequential_recommender.srgnn
   :members:
   :undoc-members:
   :show-inheritance:
