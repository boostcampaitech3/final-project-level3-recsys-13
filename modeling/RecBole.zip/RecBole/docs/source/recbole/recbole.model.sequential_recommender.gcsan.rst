.. automodule:: recbole.model.sequential_recommender.gcsan
   :members:
   :undoc-members:
   :show-inheritance:
