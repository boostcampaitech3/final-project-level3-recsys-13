.. automodule:: recbole.model.general_recommender.nais
   :members:
   :undoc-members:
   :show-inheritance:
