.. automodule:: recbole.model.sequential_recommender.transrec
   :members:
   :undoc-members:
   :show-inheritance:
