.. automodule:: recbole.model.general_recommender.ncl
   :members:
   :undoc-members:
   :show-inheritance: