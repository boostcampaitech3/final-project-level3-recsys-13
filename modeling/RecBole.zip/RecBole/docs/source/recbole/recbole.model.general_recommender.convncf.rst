.. automodule:: recbole.model.general_recommender.convncf
   :members:
   :undoc-members:
   :show-inheritance:
