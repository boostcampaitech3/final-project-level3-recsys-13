.. automodule:: recbole.model.context_aware_recommender.nfm
   :members:
   :undoc-members:
   :show-inheritance:
