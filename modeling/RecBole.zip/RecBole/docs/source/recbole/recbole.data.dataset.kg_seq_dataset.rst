.. automodule:: recbole.data.dataset.kg_seq_dataset
   :members:
   :undoc-members:
   :show-inheritance:
