recbole.model.general\_recommender
==========================================

.. toctree::
   :maxdepth: 4

   recbole.model.general_recommender.bpr
   recbole.model.general_recommender.cdae
   recbole.model.general_recommender.convncf
   recbole.model.general_recommender.dgcf
   recbole.model.general_recommender.dmf
   recbole.model.general_recommender.fism
   recbole.model.general_recommender.gcmc
   recbole.model.general_recommender.itemknn
   recbole.model.general_recommender.lightgcn
   recbole.model.general_recommender.line
   recbole.model.general_recommender.macridvae
   recbole.model.general_recommender.multidae
   recbole.model.general_recommender.multivae
   recbole.model.general_recommender.nais
   recbole.model.general_recommender.neumf
   recbole.model.general_recommender.ngcf
   recbole.model.general_recommender.pop
   recbole.model.general_recommender.spectralcf
   recbole.model.general_recommender.sgl
   recbole.model.general_recommender.ncl