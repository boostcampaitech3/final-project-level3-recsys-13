.. automodule:: recbole.model.general_recommender.multivae
   :members:
   :undoc-members:
   :show-inheritance:
