.. automodule:: recbole.model.general_recommender.cdae
   :members:
   :undoc-members:
   :show-inheritance:
