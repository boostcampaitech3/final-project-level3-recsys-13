.. automodule:: recbole.model.context_aware_recommender.fm
   :members:
   :undoc-members:
   :show-inheritance:
