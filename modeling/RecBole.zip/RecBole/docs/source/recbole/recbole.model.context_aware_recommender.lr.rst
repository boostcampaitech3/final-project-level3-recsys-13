.. automodule:: recbole.model.context_aware_recommender.lr
   :members:
   :undoc-members:
   :show-inheritance:
