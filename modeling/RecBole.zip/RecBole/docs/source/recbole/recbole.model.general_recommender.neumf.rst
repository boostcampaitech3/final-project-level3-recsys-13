.. automodule:: recbole.model.general_recommender.neumf
   :members:
   :undoc-members:
   :show-inheritance:
