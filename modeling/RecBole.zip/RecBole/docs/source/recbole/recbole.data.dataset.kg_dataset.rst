.. automodule:: recbole.data.dataset.kg_dataset
   :members:
   :undoc-members:
   :show-inheritance:
