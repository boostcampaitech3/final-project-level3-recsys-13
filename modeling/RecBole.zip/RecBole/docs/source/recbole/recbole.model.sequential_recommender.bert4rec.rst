.. automodule:: recbole.model.sequential_recommender.bert4rec
   :members:
   :undoc-members:
   :show-inheritance:
