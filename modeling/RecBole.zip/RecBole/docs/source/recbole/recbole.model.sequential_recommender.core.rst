.. automodule:: recbole.model.sequential_recommender.core
   :members:
   :undoc-members:
   :show-inheritance:
