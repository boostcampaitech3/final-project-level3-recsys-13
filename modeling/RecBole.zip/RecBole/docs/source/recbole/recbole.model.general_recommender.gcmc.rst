.. automodule:: recbole.model.general_recommender.gcmc
   :members:
   :undoc-members:
   :show-inheritance:
