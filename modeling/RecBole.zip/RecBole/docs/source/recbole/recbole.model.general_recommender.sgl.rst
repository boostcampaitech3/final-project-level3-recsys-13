.. automodule:: recbole.model.general_recommender.sgl
   :members:
   :undoc-members:
   :show-inheritance: