.. automodule:: recbole.model.sequential_recommender.s3rec
   :members:
   :undoc-members:
   :show-inheritance:
