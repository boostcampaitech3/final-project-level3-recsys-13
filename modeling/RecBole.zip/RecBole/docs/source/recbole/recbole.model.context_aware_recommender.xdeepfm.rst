.. automodule:: recbole.model.context_aware_recommender.xdeepfm
   :members:
   :undoc-members:
   :show-inheritance:
