.. automodule:: recbole.model.knowledge_aware_recommender.kgcn
   :members:
   :undoc-members:
   :show-inheritance:
