.. automodule:: recbole.model.sequential_recommender.ksr
   :members:
   :undoc-members:
   :show-inheritance:
