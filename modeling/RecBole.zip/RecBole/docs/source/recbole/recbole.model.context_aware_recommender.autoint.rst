.. automodule:: recbole.model.context_aware_recommender.autoint
   :members:
   :undoc-members:
   :show-inheritance:
