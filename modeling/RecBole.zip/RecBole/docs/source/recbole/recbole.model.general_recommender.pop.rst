.. automodule:: recbole.model.general_recommender.pop
   :members:
   :undoc-members:
   :show-inheritance:
