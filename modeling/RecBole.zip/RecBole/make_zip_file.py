import argparse
import torch
import numpy as np
import pandas as pd
from tqdm import tqdm
import pickle
import os

from recbole.quick_start import load_data_and_model

def main(args):
    path_dir = args.path
    file_list = os.listdir(path_dir)
    for file in file_list:
        if file.startswith(args.model_name):
            break
    
    _, model, dataset, _, _, test_data = load_data_and_model(os.path.join(path_dir, file))
    zip_model = (model, dataset, test_data)

    with open(os.path.join(path_dir, f'{args.model_name}.pickle'), 'wb') as f:
        pickle.dump(zip_model, f)
    
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument("--model_name", default='BPR', type=str, help="model name")
    parser.add_argument("--path", default='/opt/ml/final-project-level3-recsys-13/modeling/RecBole/saved/0', type=str, help="saved path")
    
    args = parser.parse_args()
    
    main(args)